Please add the valid youtube-api key in youtube-api.js file for the application to fetch data

const KEY = 'valid api key'.